document.addEventListener("DOMContentLoaded", function () {
    function onGooglePayLoaded() {
        console.log('Google Pay script loaded');
        const googlePayClient = new google.payments.api.PaymentsClient({ environment: 'TEST' });
        const button = googlePayClient.createButton({
            buttonColor: 'default',
            buttonType: 'long',
            onClick: onGooglePaymentButtonClicked
        });
        document.getElementById('container').appendChild(button);
    }

    function onGooglePaymentButtonClicked() {
        const paymentDataRequest = {
            apiVersion: 2,
            apiVersionMinor: 0,
            allowedPaymentMethods: [{
                type: 'CARD',
                parameters: {
                    allowedAuthMethods: ['PAN_ONLY', 'CRYPTOGRAM_3DS'],
                    allowedCardNetworks: ['AMEX', 'VISA', 'MASTERCARD']
                },
                tokenizationSpecification: {
                    type: 'PAYMENT_GATEWAY',
                    parameters: {
                        gateway: 'example',
                        gatewayMerchantId: 'exampleMerchantId'
                    }
                }
            }],
            merchantInfo: {
                merchantId: 'BCR2DN4TWW2IRYZK',
                merchantName: 'xyz company'
            },
            transactionInfo: {
                totalPriceStatus: 'FINAL',
                totalPrice: '1.00',
                currencyCode: 'USD'
            }
        };

        const paymentsClient = new google.payments.api.PaymentsClient({ environment: 'TEST' });
        paymentsClient.loadPaymentData(paymentDataRequest).then(function (paymentData) {
            processPayment(paymentData);
        }).catch(function (err) {
            console.error(err);
        });
    }

    function processPayment(paymentData) {
        fetch('/process-payment', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(paymentData)
        }).then(function (response) {
            return response.json();
        }).then(function (data) {
            console.log(data);
        }).catch(function (error) {
            console.error(error);
        });
    }

    if (document.readyState === 'complete') {
        onGooglePayLoaded();
    } else {
        window.onload = onGooglePayLoaded;
    }
});
