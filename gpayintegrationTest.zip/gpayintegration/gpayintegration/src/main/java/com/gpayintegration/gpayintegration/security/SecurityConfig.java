package com.gpayintegration.gpayintegration.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.header.writers.StaticHeadersWriter;

@Configuration
public class SecurityConfig {

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                .headers(headers -> headers
                        .contentSecurityPolicy(csp -> csp
                                .policyDirectives("default-src 'self'; " +
                                        "script-src 'self' https://pay.google.com; " +
                                        "style-src 'self' 'unsafe-inline'; " +
                                        "img-src 'self' https://www.gstatic.com https://lh3.googleusercontent.com; " +
                                        "connect-src 'self'; " +
                                        "frame-src 'self' https://pay.google.com")
                        )
                        .frameOptions(frameOptions -> frameOptions
                                .sameOrigin()
                        )
                        .referrerPolicy(referrer -> referrer
                                .policy(org.springframework.security.web.header.writers.ReferrerPolicyHeaderWriter.ReferrerPolicy.NO_REFERRER)
                        )
                        .addHeaderWriter(new StaticHeadersWriter("Permissions-Policy", "geolocation=(self)"))
                )
                .authorizeRequests(authorize -> authorize
                        .anyRequest().permitAll()
                );
        return http.build();
    }
    }