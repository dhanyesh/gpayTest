package com.gpayintegration.gpayintegration.security;
import org.springframework.boot.web.server.Cookie;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class CookieConfig {

    @Bean
    public Cookie.SameSite getSameSite() {
        return Cookie.SameSite.LAX;
    }
}