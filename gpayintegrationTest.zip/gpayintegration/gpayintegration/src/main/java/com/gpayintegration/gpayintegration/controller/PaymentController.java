package com.gpayintegration.gpayintegration.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/process-payment")
public class PaymentController {

    @PostMapping
    public ResponseEntity<String> processPayment(@RequestBody String paymentData) {
        // Process payment data here
        System.out.println("Received payment data: " + paymentData);
        // Return success or failure response
        return ResponseEntity.ok("{\"status\": \"success\"}");
    }

    @GetMapping("/")
    public String index() {
        return "index";
    }
}