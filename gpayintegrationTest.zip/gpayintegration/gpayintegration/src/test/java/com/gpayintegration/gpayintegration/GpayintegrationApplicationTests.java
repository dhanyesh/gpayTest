package com.gpayintegration.gpayintegration;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GpayintegrationApplicationTests {

	@Test
	void contextLoads() {
	}

}
